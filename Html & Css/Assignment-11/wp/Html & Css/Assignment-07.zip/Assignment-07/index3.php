<?php

$car =  "Audi"; 

switch($car)
{
    case "Audi":
        echo "Audi is amazing";
        break;
    case "Mercedes":
        echo "Mercedes is mindblowing";
        break;
    case "Jaguar":
        echo "Jaguar is the best";
        break;
     
}
?>