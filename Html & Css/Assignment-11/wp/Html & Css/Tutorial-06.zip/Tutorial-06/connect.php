<?php

    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = $_POST['password'];
    $country = $_POST['country'];
    $state = $_POST['state'];
    $city = $_POST['city'];

    //database connection

    







?>